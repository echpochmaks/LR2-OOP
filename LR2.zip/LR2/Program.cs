﻿class Program
{
    static void Main()
    {
        RacingSimulator simulator = new RacingSimulator();
        simulator.RunSimulation();
    }
}

